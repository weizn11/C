#ifndef RECV_H_INCLUDED
#define RECV_H_INCLUDED

int listen_socket_from_client();

#endif // RECV_H_INCLUDED
