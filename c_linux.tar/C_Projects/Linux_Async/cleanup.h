#ifndef CLEANUP_H_INCLUDED
#define CLEANUP_H_INCLUDED

#include "async.h"

int clean_client_connection(IO_OPERATION_DATA_NODE *pIONode,int index);

#endif // CLEANUP_H_INCLUDED
