#include <stdio.h>
#include <stdlib.h>

#include "async.h"
#include "mempool.h"

MEMPOOL_LIST *mempoolListHeader=NULL;

int main(int argc,char *argv[])
{
    int i;
    listen_client();

    return 0;
}
